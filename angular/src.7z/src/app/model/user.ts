export class User {
    id: number| undefined;
    name: string | undefined;
    email: string | undefined;
    password: string | undefined;
    registered: Date | undefined;
}
