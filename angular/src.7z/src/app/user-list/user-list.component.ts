import { Component, Input, OnInit } from '@angular/core';
import { User } from '../model/user';
import { NgbActiveModal, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { UserService } from '../service/user.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})

export class UserListComponent implements OnInit {
  user: User ;
  users: User[] | undefined;
  closeResult = '';

  constructor(private userService: UserService, private modalService: NgbModal, 
              private route: ActivatedRoute, private router: Router ) {
    this.user = new User();
  }

  ngOnInit(): void {
    this.getUsers();
  }

  open(content: any) {
    this.user.name = "";
    this.user.email = "";
    this.user.password = "";

    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
      this.save(result)
      this.getUsers();
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private save(result: any) {
    this.userService.save(this.user).subscribe(result => this.gotoUserList());
  } 
  
  
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  private gotoUserList() {
    this.router.navigate(['/getusers']);
  }

  private getUsers(){
    this.userService.findAll().subscribe((data: User[] | undefined) => {
      this.users = data;
    });
  }

}





